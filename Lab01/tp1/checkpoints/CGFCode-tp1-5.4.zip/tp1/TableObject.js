/**
 * CubeSquareUnitObject
 * @param gl {WebGLRenderingContext}
 * @constructor
 */
function TableObject(scene)
{
	CGFobject.call(this,scene);

	this.cubeObject = new CubeSquareUnitObject(this.scene);
};

TableObject.prototype = Object.create(CGFobject.prototype);
TableObject.prototype.constructor = TableObject;

TableObject.prototype.display = function ()
{
	var initialMatrix = this.scene.getMatrix();	//save initial state matrix
	
	//draw back-left leg of the table
	this.scene.scale(0.3,3.5,0.3);
	this.scene.translate(-7.8,0.5,-4.5);
	this.cubeObject.display();

	this.scene.setMatrix(initialMatrix);

	//draw back-right leg of the table
	this.scene.scale(0.3,3.5,0.3);
	this.scene.translate(7.8,0.5,-4.5);
	this.cubeObject.display();

	this.scene.setMatrix(initialMatrix);

	//draw front-left leg of the table
	this.scene.scale(0.3,3.5,0.3);
	this.scene.translate(-7.8,0.5,4.5);
	this.cubeObject.display();

	this.scene.setMatrix(initialMatrix);

	//draw front-left leg of the table
	this.scene.scale(0.3,3.5,0.3);
	this.scene.translate(7.8,0.5,4.5);
	this.cubeObject.display();

	this.scene.setMatrix(initialMatrix);

	//draw top of the table
	this.scene.scale(5,0.3,3);
	this.scene.translate(0,12.2,0);
	this.cubeObject.display();

	this.scene.setMatrix(initialMatrix);
};